<?php 
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

require_once(dirname(__FILE__).'/cloudflare.class.php');
require_once(dirname(__FILE__).'/cloudflare.user.lib.php');